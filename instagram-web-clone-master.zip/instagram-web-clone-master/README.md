# instaclone-web

A casual attempt to clone the instagram web app

To run locally, do:

    cd instaclone-web
    yarn
    yarn start

App deployed to https://instaclone.now.sh
